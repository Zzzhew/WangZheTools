library(testthat)
library(WangZheTools)

test_check("WangZheTools")
